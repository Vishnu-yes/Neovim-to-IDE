-- ============================
-- Neovim Init File
-- ============================
local function safe_require(module)
    local ok, result = pcall(require, module)
    if not ok then
        vim.notify("Failed to load " .. module .. "\n" .. result, vim.log.levels.ERROR)
        return nil
    end
    return result
end

-- ----------------------------
-- 1. Basic Settings
-- ----------------------------
safe_require("user.Basics.env")        -- environment variables
safe_require("user.Basics.options")    -- vim options
safe_require("user.Basics.mappings")   -- keymaps
safe_require("user.Basics.autoreload") -- autoreload config
safe_require("user.Basics.plugins")    -- plugin setup with lazy.nvim
safe_require("user.Basics.utilities")  -- helper function

-- ----------------------------
-- 2. UI Enhancements
-- ----------------------------
safe_require("user.UI.ui")               -- colorscheme, statusline etc.
safe_require("user.UI.dashboard")        -- alpha dashboard
safe_require("user.UI.DAP_UI")           -- debug UI (dap + dap-ui)
safe_require("user.UI.diagonasticsigns") -- diagonastic signs
safe_require("user.UI.IBL")              -- indent lines
safe_require("user.UI.bufferline")       -- bufferline
safe_require("user.UI.gitsigns")         -- gitsigns
-- ----------------------------
-- 3. Plugin Configurations
-- ----------------------------
safe_require("user.config.lsp")        -- LSP servers
safe_require("user.config.cmp")        -- completion
safe_require("user.config.autopairs")  -- autopairs
safe_require("user.config.formattor")  -- formatter
safe_require("user.config.notify")     -- notifications
safe_require("user.config.nvimtree")   -- file explorer
safe_require("user.config.telescope")  -- telescope
safe_require("user.config.toggleterm") -- terminal
safe_require("user.config.workspace")  -- workspace mgmt
safe_require("user.config.sessions")   -- session mgmt

-- ----------------------------
-- 4. Custom Plugin Configs
-- ----------------------------
safe_require("user.config.custom.trouble")
safe_require("user.config.custom.harpoon")
safe_require("user.config.custom.refactoring")
safe_require("user.config.custom.todo")
safe_require("user.config.custom.sessions") -- if different from config/sessions.lua
