local hooks = require("ibl.hooks")
hooks.register(hooks.type.HIGHLIGHT_SETUP, function()
    vim.api.nvim_set_hl(0, "IblIndent", { fg = "#44475a" }) -- dim gray
    vim.api.nvim_set_hl(0, "IblScope", { fg = "#7aa2f7" })  -- scope highlight (blue-ish)
end)
require("ibl").setup({
    indent = { char = "│" },
    scope = { enabled = true, highlight = "IblScope" },
    exclude = { filetypes = { "help", "alpha", "dashboard", "NvimTree", "terminal", "lazy" } },
})
