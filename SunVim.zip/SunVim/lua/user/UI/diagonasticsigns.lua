---Diagnostic Signs


vim.diagnostic.config({
    signs =
    {
        text =
        {
            [vim.diagnostic.severity.ERROR] = "",
            [vim.diagnostic.severity.WARN] = "",
            [vim.diagnostic.severity.HINT] = "",
            [vim.diagnostic.severity.INFO] = "",
        },
        numhl =
        {
            [vim.diagnostic.severity.ERROR] =
            "DiagnosticSignError",
            [vim.diagnostic.severity.WARN] = "DiagnosticSignWarn",
            [vim.diagnostic.severity.HINT] = "DiagnosticSignHint",
            [vim.diagnostic.severity.INFO] = "DiagnosticSignInfo",
        },
    },
})
vim.cmd([[
  highlight LineNr guibg=#1a1b26 guifg=#7f849c
  highlight SignColumn guibg=#1a1b26
]])
