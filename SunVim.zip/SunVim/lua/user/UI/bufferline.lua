-- =====================
-- Bufferline
-- =====================
require("bufferline").setup({
    options = {
        numbers = "ordinal",
        indicator = { icon = "▌", style = "icon" },
        buffer_close_icon = "⨯", -- clean per-buffer close                                                                                     modified_icon = "●", -- subtle modified dot
        close_icon = "", -- global close
        show_buffer_icons = true,
        show_buffer_close_icons = true,
        separator_style = "thin", -- cleaner look
        always_show_bufferline = true,
        offsets = {
            { filetype = "NvimTree", text = "File Explorer", text_align = "left" }
        },

        -- 🔹 NEW: only show the currently active buffer
        custom_filter = function(buf_number, buf_numbers)
            return buf_number == vim.fn.bufnr("%")
        end,
    },

    highlights = {
        fill = { bg = "#1e1e1e" },                                         -- overall background
        background = { fg = "#6d6d6d", bg = "#1e1e1e" },                   -- inactive tabs
        buffer_selected = { fg = "#ffffff", bold = true, bg = "#252526" }, -- active tab
        indicator_selected = { fg = "#569cd6", bg = "#252526" },           -- blue indicator
        modified = { fg = "#dcdcaa", bg = "#1e1e1e" },                     -- yellow modified dot
        modified_selected = { fg = "#dcdcaa", bg = "#252526" },
        close_button = { fg = "#c586c0", bg = "#1e1e1e" },                 -- lavender close
        close_button_selected = { fg = "#ffffff", bg = "#252526" },
        separator = { fg = "#1e1e1e", bg = "#1e1e1e" },                    -- invisible separators
        separator_selected = { fg = "#252526", bg = "#252526" },
    },
})
