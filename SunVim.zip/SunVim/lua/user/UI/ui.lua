-- UI Elementts Fall Here
--Add all UI things etc here.
-- =====================
-- Basic editor settings
-- =====================

function _G.MyTabline()
    local current_tab = vim.fn.tabpagenr()
    local total_tabs = vim.fn.tabpagenr('$')

    -- Get filename of current tab
    local win = vim.fn.tabpagewinnr(current_tab)
    local buf = vim.fn.tabpagebuflist(current_tab)[win]
    local name = vim.fn.fnamemodify(vim.fn.bufname(buf), ":t")
    if name == "" then
        name = "[No Name]"
    end

    -- Indicator: if there are more tabs
    local indicator = ""
    if total_tabs > current_tab then
        indicator = string.format("[%d m]", current_tab)
    else
        indicator = string.format("[%d]", current_tab)
    end

    -- Return with highlights
    return "%#TabLineSel# " .. name .. " ⨯   " .. indicator .. " ⨯ %#TabLineFill#"
end

-- =====================
-- UI tweaks: colorscheme, diagnostics signs, gutter icons
-- =====================
vim.o.background = "dark"
pcall(vim.cmd, "colorscheme vscode") -- default theme
-- tomorrow is also warm theme , darkplus is too best.
vim.cmd([[
  highlight Comment cterm=NONE gui=NONE
]])
