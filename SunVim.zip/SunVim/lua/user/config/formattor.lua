-- =====================
-- 14) Formatter setup
-- =====================
local conform = require("conform")

conform.setup({
    formatters_by_ft = {
        python = { "black" },
        cpp = { "clang-format" },
        c = { "clang-format" },
        lua = { "stylua" },
        javascript = { "prettier" },
        typescript = { "prettier" },
    },
    format_on_save = { timeout_ms = 1000, lsp_fallback = true },
})

-- =================================
-- Toggle / Control Autoformatting
-- =================================
local autoformat_enabled = true

vim.api.nvim_create_user_command("Fomf", function()
    autoformat_enabled = true
    vim.notify("Autoformat on save: ENABLED", vim.log.levels.INFO)
end, {})

vim.api.nvim_create_user_command("Fomt", function()
    autoformat_enabled = not autoformat_enabled
    vim.notify("Autoformat on save: " .. (autoformat_enabled and "ENABLED" or "DISABLED"), vim.log.levels.INFO)
end, {})

-- Override Conform's on-save hook
vim.api.nvim_create_autocmd("BufWritePre", {
    callback = function(args)
        if autoformat_enabled then
            conform.format({ bufnr = args.buf })
        end
    end,
})

-- =================================
-- Power Formatting Commands
-- =================================

-- Format the whole buffer
vim.api.nvim_create_user_command("Fmt", function()
    conform.format({ async = true, lsp_fallback = true })
end, {})

-- Format only visually selected range
vim.api.nvim_create_user_command("Fmtv", function()
    local mode = vim.fn.mode()
    if mode ~= "v" and mode ~= "V" then
        vim.notify("Not in visual mode", vim.log.levels.WARN)
        return
    end
    local start_pos = vim.fn.getpos("'<")
    local end_pos = vim.fn.getpos("'>")
    conform.format({
        range = {
            start = { start_pos[2], start_pos[3] - 1 },
            ["end"] = { end_pos[2], end_pos[3] },
        },
        async = true,
        lsp_fallback = true,
    })
end, {})
