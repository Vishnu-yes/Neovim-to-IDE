-- =====================
-- 8) Nvim-tree setup (filesystem)
-- =====================
require("nvim-tree").setup({
    view = { width = 30, side = "left" },
    renderer = { highlight_git = true, icons = { show = { git = true, folder = true, file = true } } },
    filters = { dotfiles = false },
})
vim.keymap.set("n", "<leader>e", ":NvimTreeToggle<CR>", { desc = "Toggle File Explorer" })
