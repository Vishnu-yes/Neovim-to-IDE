-- =====================
-- 17) Sessions
-- =====================
require("auto-session").setup({
    auto_restore_enabled = true,
    auto_session_suppress_dirs = { "~/", "/" },
})
-- Keymaps
vim.keymap.set("n", "<leader>pw", ":WorkspacesOpen<CR>", { desc = "Open Workspaces" })
