--Refactoring
require('refactoring').setup({})
vim.keymap.set("v", "<leader>rr", function() require('refactoring').select_refactor() end)
