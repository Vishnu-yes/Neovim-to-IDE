--Trouble Diagnostic UI
require("trouble").setup()
-- Keybinding example:
vim.keymap.set("n", "<leader>lr", "<cmd>Trouble diagnostics toggle<cr>", { silent = true, noremap = true })
