-- =====================
-- 12) AutoPairs (automatic brackets/quotes)
-- =====================
require("nvim-autopairs").setup({
    check_ts = true, -- enable treesitter integration
    disable_filetype = { "TelescopePrompt", "vim" },
})
