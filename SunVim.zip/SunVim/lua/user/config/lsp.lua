-- =====================================================
-- Chad Coder LSP Giant ⚡ (Future-Proof, Nvim 0.11+)
-- =====================================================
-- This config uses the new vim.lsp.config + vim.lsp.enable API
-- lspconfig is no longer required ✅
-- =====================================================

-- -------------------------
-- 1. Function: on_attach
-- -------------------------
-- Runs every time an LSP server attaches to a buffer.
-- Here we set up keymaps for LSP actions.
local function on_attach(_, bufnr)
    local opts = { noremap = true, silent = true, buffer = bufnr }
    local map = vim.keymap.set

    map("n", "gd", vim.lsp.buf.definition, opts)        -- Go to definition
    map("n", "K", vim.lsp.buf.hover, opts)              -- Show hover docs
    map("n", "gr", vim.lsp.buf.references, opts)        -- Show references
    map("n", "<leader>rn", vim.lsp.buf.rename, opts)    -- Rename symbol
    map("n", "<leader>ca", vim.lsp.buf.code_action, opts) -- Code actions
    map("n", "<leader>f", function()                    -- Format file
        vim.lsp.buf.format { async = true }
    end, opts)
end

-- -------------------------
-- 2. Capabilities
-- -------------------------
-- Enhances LSP capabilities (completion, snippets, etc.)
-- Works with nvim-cmp if installed
local capabilities = require("cmp_nvim_lsp").default_capabilities()

-- -------------------------
-- 3. Default config
-- -------------------------
-- This will be merged into each server’s setup
local default_config = {
    on_attach = on_attach,
    capabilities = capabilities,
}

-- -------------------------
-- 4. LSP Servers
-- -------------------------
-- Big Chad list of language servers.
-- Add/remove servers depending on what you use.
local servers = {
    -- 🔹 Core tools
    bashls = {}, -- Bash / Shell
    jsonls = {}, -- JSON
    yamlls = {}, -- YAML
    dockerls = {}, -- Dockerfile
    marksman = {}, -- Markdown

    -- 🔹 Web Development
    html = {},   -- HTML
    cssls = {},  -- CSS
    tsserver = {}, -- JavaScript / TypeScript
    eslint = {}, -- ESLint

    -- 🔹 System / Low-level
    clangd = { -- C / C++
        cmd = { "clangd", "--background-index" },
    },
    cmake = {}, -- CMake
    vimls = {}, -- Vimscript

    -- 🔹 Scripting & Config
    pyright = {}, -- Python
    lua_ls = {  -- Lua (for Neovim config/dev)
        settings = {
            Lua = {
                diagnostics = { globals = { "vim" } },
                workspace = { checkThirdParty = false },
                telemetry = { enable = false },
            },
        },
    },

    -- 🔹 Extra Chad Power
    rust_analyzer = {}, -- Rust
    gopls = {},       -- Go
    phpactor = {},    -- PHP
}

-- -------------------------
-- 5. Setup & Enable
-- -------------------------
-- Loop over all servers, apply default config + server-specific opts
for server, opts in pairs(servers) do
    vim.lsp.config(server, vim.tbl_deep_extend("force", default_config, opts))
end

-- Finally, enable all servers 🎉
vim.lsp.enable(vim.tbl_keys(servers))
