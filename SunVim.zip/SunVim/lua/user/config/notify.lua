-- =====================
-- Notify etc
-- =====================
vim.notify = require("notify") --- notify
-- Load the plugin
local notify = require("notify")

notify.setup({
    -- Default timeout for notifications (ms)
    timeout = 3000,

    -- Animation style for notifications
    -- options: "fade", "slide", "fade_in_slide_out", "static"
    stages = "fade_in_slide_out",

    -- Background color behind notifications
    background_colour = "#000000",

    -- Minimum log level
    -- :help vim.log.levels → TRACE, DEBUG, INFO, WARN, ERROR
    level = vim.log.levels.INFO,

    -- Max width/height of notification window
    max_width = math.floor(vim.o.columns * 0.4),
    max_height = math.floor(vim.o.lines * 0.2),

    -- Render style: "default", "minimal", "simple", "compact"
    render = "default",
})

-- Replace Neovim’s built-in notification function
vim.notify = notify
