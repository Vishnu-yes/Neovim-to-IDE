-- ~/.config/nvim/lua/user/Basics/autoreload.lua

vim.api.nvim_create_autocmd("BufWritePost", {
    pattern = vim.fn.stdpath("config") .. "/lua/user/**/*.lua",
    callback = function(opts)
        local file = opts.file

        -- Strip everything up to /lua/
        local relpath = file:match("lua/(.*)")
        if not relpath then return end

        -- Convert to module name (e.g. user.config.lsp)
        local modname = relpath
            :gsub("%.lua$", "") -- remove .lua
            :gsub("/", ".") -- replace / with .

        -- Clear cache
        package.loaded[modname] = nil

        -- Reload
        local ok, err = pcall(require, modname)
        if ok then
            vim.notify("Reloaded " .. modname, vim.log.levels.INFO, { title = "Nvim Config" })
        else
            vim.notify("Error reloading " .. modname .. "\n\n" .. err, vim.log.levels.ERROR, { title = "Nvim Config" })
        end
    end,
})
