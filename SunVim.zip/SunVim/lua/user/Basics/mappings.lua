--=========================
--Custom Command
--=========================
vim.api.nvim_create_user_command("Tldr", function()
    vim.cmd("Trouble diagnostics toggle")
end, {})
