-- Your Plugins must be added here.
-- =====================
-- (1) Bootstrap lazy.nvim
-- =====================
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
    vim.fn.system({
        "git",
        "clone",
        "--filter=blob:none",
        "https://github.com/folke/lazy.nvim.git",
        lazypath, })
end
vim.opt.rtp:prepend(lazypath)
-- =====================
-- 5) Plugins (lazy.nvim)
-- =====================
require("lazy").setup({
    -- core
    { "nvim-lua/plenary.nvim",               lazy = true },
    { "nvim-tree/nvim-web-devicons",         lazy = true },

    -- themes (lots of great defaults)
    { "ellisonleao/gruvbox.nvim",            priority = 1000 },
    { "projekt0n/github-nvim-theme",         name = "github-theme",                 priority = 999 },
    { "lunarvim/colorschemes" }, -- LunarVim’s default colorscheme collection
    { "folke/tokyonight.nvim" },
    { "catppuccin/nvim",                     name = "catppuccin" },
    { "EdenEast/nightfox.nvim" },
    { "shaunsingh/nord.nvim" },
    { "Mofiqul/vscode.nvim" },
    { "navarasu/onedark.nvim" },
    { "rebelot/kanagawa.nvim" },
    { "chriskempson/vim-tomorrow-theme" },

    -- UI
    { "lewis6991/gitsigns.nvim",             event = { "BufReadPre", "BufNewFile" } },
    { "lukas-reineke/indent-blankline.nvim", main = "ibl",                          event = { "BufReadPost", "BufNewFile" } },
    {
        "akinsho/bufferline.nvim",
        version = "*",
        dependencies = "nvim-tree/nvim-web-devicons",
        event = "VeryLazy",
    },
    {
        "nvim-tree/nvim-tree.lua",
        dependencies = { "nvim-tree/nvim-web-devicons" },
    },

    -- completion
    {
        "hrsh7th/nvim-cmp",
        dependencies = {
            "hrsh7th/cmp-nvim-lsp",
            "hrsh7th/cmp-buffer",
            "hrsh7th/cmp-path",
            "L3MON4D3/LuaSnip",
            "saadparwaiz1/cmp_luasnip",
        },
    },

    -- autopairs
    { "windwp/nvim-autopairs",       event = "InsertEnter" },
    -- Your Plugins here

    -- ==== Formatter
    { "stevearc/conform.nvim",       event = "BufWritePre" },

    -- ===== Statusline
    { "nvim-lualine/lualine.nvim",   dependencies = { "nvim-tree/nvim-web-devicons" } },

    -- ===== Dap + UI
    { "mfussenegger/nvim-dap" },
    { "rcarriga/nvim-dap-ui",        dependencies = { "mfussenegger/nvim-dap" } },
    { "williamboman/mason.nvim",     enabled = false }, -- keep off since you don’t use mason
    { "nvim-neotest/nvim-nio" },                        -- dependency

    -- ==== Sessions & workspace
    { "rmagatti/auto-session" },
    { "natecraddock/workspaces.nvim" },

    -- ====== Notify
    { "rcarriga/nvim-notify" },

    -- Dashboard (startup screen)
    -- { "nvimdev/dashboard-nvim", event = "VimEnter" },
    -- alpha.nvim (dashboard)
    {
        "goolord/alpha-nvim",
        event = "VimEnter",
        dependencies = { "nvim-tree/nvim-web-devicons" },
        config = function()
        end,
    },
    -- Project.nvim (detect project roots)
    { "ahmedkhalf/project.nvim" },

    -- Trouble.nvim (diagnostics / references UI)
    { "folke/trouble.nvim",     dependencies = { "nvim-tree/nvim-web-devicons" } },

    -- Harpoon (quick file navigation)
    {
        "ThePrimeagen/harpoon",
        branch = "harpoon2",
        dependencies = { "nvim-lua/plenary.nvim" },
    },

    -- Refactoring
    {
        "ThePrimeagen/refactoring.nvim",
        dependencies = { "nvim-lua/plenary.nvim", "nvim-treesitter/nvim-treesitter" },
    },

    -- Todo Comments
    { "folke/todo-comments.nvim", dependencies = { "nvim-lua/plenary.nvim" } },

    -- Neoscroll (smooth scrolling)
    { "karb94/neoscroll.nvim",    config = true },

    -- Your custom plugins end here

    -- telescope
    {
        "nvim-telescope/telescope.nvim",
        tag = "0.1.5",
        dependencies = { "nvim-lua/plenary.nvim", "nvim-tree/nvim-web-devicons" },
    },
    {
        "nvim-telescope/telescope-fzf-native.nvim",
        build = "make",
        cond = function()
            return vim.fn
                .executable('make') == 1
        end
    },
    { "nvim-telescope/telescope-file-browser.nvim" },

    -- treesitter
    { "nvim-treesitter/nvim-treesitter",           build = ":TSUpdate" },

    -- LSP config
    { "neovim/nvim-lspconfig",                     event = { "BufReadPre", "BufNewFile" }, dependencies = { "hrsh7th/cmp-nvim-lsp" } },

    -- snippets
    { "L3MON4D3/LuaSnip",                          lazy = true },
    { "honza/vim-snippets",                        lazy = true },

    -- terminal
    { "akinsho/toggleterm.nvim",                   version = "*" },

    -- ====================
    --  Add More From here
    -- ====================
}) ---- Plugins Stop.
